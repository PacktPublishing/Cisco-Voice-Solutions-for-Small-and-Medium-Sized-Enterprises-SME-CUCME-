Background File 7970/71/75 Readme File
=================================================================
The following instructions are provided to help a system administrator
load the background files for 7970/71/75 phones onto their CME System.  The 
background TAR package already has the necessary files created in the 
relevant directories.  Thus all the administrator has to do is extract
the "7970-71-75-backgroundsv1.tar" into the flash root directory and the package
will create the necessary directories.

(1) Extract the "7970-71-75-backgroundsv1.tar" from the flash root directory on CME.
This package will automatically create the appropriate directories and put the necessary
files in their respective directories.  The syntax for the command is:

archive tar /xtract tftp://tftp-ip-address/package-name.tar flash:

 CME#archive tar /xtract tftp://10.10.10.11/7970-71-75-backgroundsv1.tar flash:
  Loading 7970-71-75-backgroundsv1.tar from 10.10.10.11 (via Vlan10): !
  Desktops/ (directory) 0 (bytes)
  Desktops/320x212x12/ (directory) 0 (bytes)
  extracting Desktops/320x212x12/CampusNight.png (131470 bytes)
  extracting Desktops/320x212x12/CiscoFountain.png (80565 bytes)
  extracting Desktops/320x212x12/CiscoLogo.png (8156 bytes)
  extracting Desktops/320x212x12/Fountain.png (138278 bytes)!
  extracting Desktops/320x212x12/List.xml (726 bytes)
  extracting Desktops/320x212x12/MorroRock.png (109076 bytes)
  extracting Desktops/320x212x12/NantucketFlowers.png (108087 bytes)!
  extracting Desktops/320x212x12/TN-CampusNight.png (10820 bytes)
  extracting Desktops/320x212x12/TN-CiscoFountain.png (9657 bytes)
  extracting Desktops/320x212x12/TN-CiscoLogo.png (2089 bytes)
  extracting Desktops/320x212x12/TN-Fountain.png (7953 bytes)
  extracting Desktops/320x212x12/TN-MorroRock.png (7274 bytes)
  extracting Desktops/320x212x12/TN-NantucketFlowers.png (9933 bytes)
  Desktops/320x216x16/ (directory) 0 (bytes)
  extracting Desktops/320x216x16/List.xml (726 bytes)
  Desktops/320x212x16/ (directory) 0 (bytes)
  extracting Desktops/320x212x16/List.xml (726 bytes)
[OK - 641024 bytes]


(2) Add the appropriate TFTP server commands to server the files to the phones

tftp-server flash:Desktops/320x212x12/CampusNight.png
tftp-server flash:Desktops/320x212x12/CiscoFountain.png
tftp-server flash:Desktops/320x212x12/MorroRock.png
tftp-server flash:Desktops/320x212x12/NantucketFlowers.png
tftp-server flash:Desktops/320x212x12/TN-CampusNight.png
tftp-server flash:Desktops/320x212x12/TN-CiscoFountain.png
tftp-server flash:Desktops/320x212x12/TN-Fountain.png
tftp-server flash:Desktops/320x212x12/TN-MorroRock.png
tftp-server flash:Desktops/320x212x12/TN-NantucketFlowers.png
tftp-server flash:Desktops/320x212x12/Fountain.png
tftp-server flash:Desktops/320x212x12/CiscoLogo.png
tftp-server flash:Desktops/320x212x12/TN-CiscoLogo.png
tftp-server flash:Desktops/320x212x12/List.xml
tftp-server flash:Desktops/320x216x16/List.xml
tftp-server flash:Desktops/320x212x16/List.xml


SAMPLE:
CME#conf t
Enter configuration commands, one per line.  End with CNTL/Z.
CME(config)#tftp-server flash:Desktops/320x212x12/CampusNight.png
CME(config)#tftp-server flash:Desktops/320x212x12/CiscoFountain.png
CME(config)#tftp-server flash:Desktops/320x212x12/CiscoLogo.png
CME(config)#tftp-server flash:Desktops/320x212x12/Fountain.png
CME(config)#tftp-server flash:Desktops/320x212x12/MorroRock.png
CME(config)#tftp-server flash:Desktops/320x212x12/NantucketFlowers.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-CampusNight.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-CiscoFountain.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-CiscoLogo.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-Fountain.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-MorroRock.png
CME(config)#tftp-server flash:Desktops/320x212x12/TN-NantucketFlowers.png
CME(config)#tftp-server flash:Desktops/320x212x12/List.xml
CME(config)#tftp-server flash:Desktops/320x216x16/List.xml
CME(config)#tftp-server flash:Desktops/320x212x16/List.xml
CME(config)#end


NOTE: The reason why the "List.xml" file is added to 3 different directories is because different
phone types look for the "List.xml" file in different directories.  For example, the 7970/71 phones
will look for the "List.xml" file in the "Desktops/320x212x12" directory while the 7975 phones will
look for the "List.xml" file in the "Desktops/320x216x16" directory.


(3) To load background images onto the phone, select SETTINGS > USER 
PREFERENCES > BACKGROUND IMAGES on the phone.  When you do this, the phone will
request the "List.xml" file from the CME system to provide a list of background images that it
can download.



TROUBLESHOOTING:
If your phone can't access the background images, check the following:
(1) That you have the "List.xml" file in the correct folder
(2) That you have the png.files referenced in the "List.xml" file
  
  
  
Customize: To customize background images for the 7970/71/75 phones, refer to the following link:
http://www.cisco.com/en/US/products/sw/voicesw/ps4625/products_tech_note09186a008062495a.shtml


 